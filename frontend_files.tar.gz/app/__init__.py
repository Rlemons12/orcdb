from flask import Flask
from pathlib import Path

def create_app():
    app = Flask(__name__)
    
    # Configuration
    app.config['SECRET_KEY'] = 'dev-secret-key-change-in-production'
    app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size
    
    # Project root
    app.config['PROJECT_ROOT'] = Path(__file__).resolve().parents[1]
    app.config['OUTPUT_BASE_DIR'] = app.config['PROJECT_ROOT'] / "outputs"
    
    # Register blueprints
    from app.routes import main, reports, api
    app.register_blueprint(main.bp)
    app.register_blueprint(reports.bp)
    app.register_blueprint(api.bp)
    
    return app
