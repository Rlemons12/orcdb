// ===========================
// Modal Management
// ===========================

class Modal {
    constructor(modalId) {
        this.modal = document.getElementById(modalId);
        this.closeBtn = this.modal.querySelector('.close');
        
        // Close on X button
        this.closeBtn.addEventListener('click', () => this.close());
        
        // Close on outside click
        this.modal.addEventListener('click', (e) => {
            if (e.target === this.modal) {
                this.close();
            }
        });
    }
    
    open() {
        this.modal.classList.add('show');
        document.body.style.overflow = 'hidden';
    }
    
    close() {
        this.modal.classList.remove('show');
        document.body.style.overflow = '';
    }
}

// ===========================
// Generate Report Modal
// ===========================

const generateModal = new Modal('generateModal');
const jobStatusModal = new Modal('jobStatusModal');

// Open generate modal
document.getElementById('generateReportBtn').addEventListener('click', (e) => {
    e.preventDefault();
    loadAvailableReports();
    generateModal.open();
});

// Load available reports
async function loadAvailableReports() {
    const container = document.getElementById('reportTypesList');
    container.innerHTML = '<div class="loading">Loading available reports...</div>';
    
    try {
        const response = await fetch('/api/reports/available');
        const reports = await response.json();
        
        if (reports.length === 0) {
            container.innerHTML = '<p>No reports available</p>';
            return;
        }
        
        container.innerHTML = reports.map(report => `
            <div class="report-type-card" onclick="generateReport('${report.id}')">
                <h3><i class="fas fa-file-alt"></i> ${report.name}</h3>
                <p>${report.description}</p>
            </div>
        `).join('');
        
    } catch (error) {
        console.error('Error loading reports:', error);
        container.innerHTML = '<p class="text-danger">Error loading reports</p>';
    }
}

// Generate a report
async function generateReport(reportId) {
    try {
        const response = await fetch('/api/reports/run', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ report_id: reportId })
        });
        
        const result = await response.json();
        
        if (response.ok) {
            generateModal.close();
            showNotification('Report generation started!', 'success');
            
            // Monitor job status
            monitorJob(result.job_id);
        } else {
            showNotification(result.error || 'Failed to start report', 'error');
        }
        
    } catch (error) {
        console.error('Error generating report:', error);
        showNotification('Error starting report generation', 'error');
    }
}

// ===========================
// Job Monitoring
// ===========================

let activeMonitors = new Set();

async function monitorJob(jobId) {
    if (activeMonitors.has(jobId)) return;
    activeMonitors.add(jobId);
    
    const checkStatus = async () => {
        try {
            const response = await fetch(`/api/jobs/${jobId}`);
            const job = await response.json();
            
            if (job.status === 'completed') {
                activeMonitors.delete(jobId);
                showNotification(`Report "${job.name}" completed successfully!`, 'success');
                
                // Refresh page after short delay
                setTimeout(() => {
                    window.location.reload();
                }, 2000);
                
            } else if (job.status === 'failed') {
                activeMonitors.delete(jobId);
                showNotification(`Report "${job.name}" failed: ${job.error}`, 'error');
                
            } else {
                // Still running, check again
                setTimeout(checkStatus, 2000);
            }
            
        } catch (error) {
            console.error('Error checking job status:', error);
            activeMonitors.delete(jobId);
        }
    };
    
    checkStatus();
}

// ===========================
// View All Jobs
// ===========================

async function loadAllJobs() {
    const content = document.getElementById('jobStatusContent');
    content.innerHTML = '<div class="loading">Loading jobs...</div>';
    
    jobStatusModal.open();
    
    try {
        const response = await fetch('/api/jobs');
        const jobs = await response.json();
        
        if (jobs.length === 0) {
            content.innerHTML = '<p>No jobs found</p>';
            return;
        }
        
        content.innerHTML = `
            <div style="max-height: 400px; overflow-y: auto;">
                ${jobs.map(job => `
                    <div class="job-card" style="border: 1px solid #e5e7eb; border-radius: 0.375rem; padding: 1rem; margin-bottom: 1rem;">
                        <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 0.5rem;">
                            <h3 style="margin: 0; font-size: 1rem;">${job.name}</h3>
                            <span class="badge badge-${getStatusColor(job.status)}">${job.status}</span>
                        </div>
                        <p style="font-size: 0.875rem; color: #6b7280; margin: 0;">
                            <i class="fas fa-clock"></i> Started: ${formatDateTime(job.started_at)}
                        </p>
                        ${job.completed_at ? `
                            <p style="font-size: 0.875rem; color: #6b7280; margin: 0;">
                                <i class="fas fa-check-circle"></i> Completed: ${formatDateTime(job.completed_at)}
                            </p>
                        ` : ''}
                        ${job.error ? `
                            <p style="color: #ef4444; font-size: 0.875rem; margin-top: 0.5rem;">
                                <i class="fas fa-exclamation-circle"></i> ${job.error}
                            </p>
                        ` : ''}
                    </div>
                `).join('')}
            </div>
        `;
        
    } catch (error) {
        console.error('Error loading jobs:', error);
        content.innerHTML = '<p class="text-danger">Error loading jobs</p>';
    }
}

function getStatusColor(status) {
    const colors = {
        'running': 'info',
        'completed': 'primary',
        'failed': 'danger'
    };
    return colors[status] || 'primary';
}

// ===========================
// Notifications
// ===========================

function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6'};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 0.375rem;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
        z-index: 2000;
        animation: slideInRight 0.3s;
        max-width: 400px;
    `;
    
    notification.innerHTML = `
        <div style="display: flex; align-items: center; gap: 0.75rem;">
            <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
            <span>${message}</span>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Remove after 5 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s';
        setTimeout(() => notification.remove(), 300);
    }, 5000);
}

// Add notification animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// ===========================
// Utility Functions
// ===========================

function formatDateTime(isoString) {
    if (!isoString) return 'N/A';
    
    const date = new Date(isoString);
    return date.toLocaleString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// ===========================
// Auto-refresh for active jobs
// ===========================

// Check for active jobs on page load and set up auto-refresh
window.addEventListener('load', async () => {
    try {
        const response = await fetch('/api/jobs');
        const jobs = await response.json();
        
        // Monitor any running jobs
        jobs.forEach(job => {
            if (job.status === 'running') {
                monitorJob(job.id);
            }
        });
        
    } catch (error) {
        console.error('Error checking for active jobs:', error);
    }
});

// ===========================
// Keyboard Shortcuts
// ===========================

document.addEventListener('keydown', (e) => {
    // Escape to close modals
    if (e.key === 'Escape') {
        generateModal.close();
        jobStatusModal.close();
    }
    
    // Ctrl/Cmd + G to open generate modal
    if ((e.ctrlKey || e.metaKey) && e.key === 'g') {
        e.preventDefault();
        document.getElementById('generateReportBtn').click();
    }
});
