from flask import Blueprint, jsonify, request, current_app
from pathlib import Path
import subprocess
import threading
import time
from datetime import datetime

bp = Blueprint('api', __name__, url_prefix='/api')

# In-memory job tracking (use Redis/database for production)
active_jobs = {}
job_history = []


@bp.route('/reports/available')
def available_reports():
    """Get list of available report types"""
    project_root = current_app.config['PROJECT_ROOT']
    
    reports = [
        {
            'id': 'qa_daily',
            'name': 'QA Daily Results',
            'description': 'QA results for the last 24 hours',
            'script': 'run_qa_daily_report.py',
            'category': 'qa_daily_results'
        },
        {
            'id': 'level10_dm',
            'name': 'Level 10 DM Open Work Orders',
            'description': 'Open work orders for Level 10 DM',
            'script': 'run_level10_dm_report.py',
            'category': 'level10_dm_open'
        },
        # Add more report types here as they're created
    ]
    
    return jsonify(reports)


@bp.route('/reports/run', methods=['POST'])
def run_report():
    """Execute a report generation script"""
    data = request.json
    report_id = data.get('report_id')
    
    if not report_id:
        return jsonify({'error': 'report_id is required'}), 400
    
    # Find the report configuration
    reports = {
        'qa_daily': {
            'script': 'run_qa_daily_report.py',
            'name': 'QA Daily Results'
        },
        'level10_dm': {
            'script': 'run_level10_dm_report.py',
            'name': 'Level 10 DM Open Work Orders'
        }
    }
    
    if report_id not in reports:
        return jsonify({'error': 'Invalid report_id'}), 400
    
    report_config = reports[report_id]
    project_root = current_app.config['PROJECT_ROOT']
    script_path = project_root / report_config['script']
    
    if not script_path.exists():
        return jsonify({'error': 'Report script not found'}), 404
    
    # Create job ID
    job_id = f"{report_id}_{int(time.time())}"
    
    # Initialize job tracking
    active_jobs[job_id] = {
        'id': job_id,
        'report_id': report_id,
        'name': report_config['name'],
        'status': 'running',
        'started_at': datetime.now().isoformat(),
        'progress': 0
    }
    
    # Run in background thread
    thread = threading.Thread(
        target=execute_report_script,
        args=(job_id, script_path, project_root)
    )
    thread.daemon = True
    thread.start()
    
    return jsonify({
        'job_id': job_id,
        'status': 'started',
        'message': f'Report generation started: {report_config["name"]}'
    })


@bp.route('/jobs/<job_id>')
def job_status(job_id):
    """Get status of a running or completed job"""
    # Check active jobs
    if job_id in active_jobs:
        return jsonify(active_jobs[job_id])
    
    # Check history
    for job in job_history:
        if job['id'] == job_id:
            return jsonify(job)
    
    return jsonify({'error': 'Job not found'}), 404


@bp.route('/jobs')
def all_jobs():
    """Get all jobs (active and recent history)"""
    all_jobs_list = list(active_jobs.values())
    all_jobs_list.extend(job_history[-20:])  # Last 20 from history
    
    # Sort by start time, newest first
    all_jobs_list.sort(
        key=lambda x: x.get('started_at', ''),
        reverse=True
    )
    
    return jsonify(all_jobs_list)


def execute_report_script(job_id: str, script_path: Path, project_root: Path):
    """Execute a report script in background"""
    try:
        # Update status
        active_jobs[job_id]['status'] = 'running'
        active_jobs[job_id]['progress'] = 10
        
        # Execute script
        result = subprocess.run(
            ['python', str(script_path)],
            cwd=str(project_root),
            capture_output=True,
            text=True,
            timeout=300  # 5 minute timeout
        )
        
        # Update with results
        if result.returncode == 0:
            active_jobs[job_id].update({
                'status': 'completed',
                'progress': 100,
                'completed_at': datetime.now().isoformat(),
                'output': result.stdout[-500:] if result.stdout else ''  # Last 500 chars
            })
        else:
            active_jobs[job_id].update({
                'status': 'failed',
                'progress': 0,
                'completed_at': datetime.now().isoformat(),
                'error': result.stderr[-500:] if result.stderr else 'Unknown error',
                'output': result.stdout[-500:] if result.stdout else ''
            })
    
    except subprocess.TimeoutExpired:
        active_jobs[job_id].update({
            'status': 'failed',
            'error': 'Script execution timeout (5 minutes)',
            'completed_at': datetime.now().isoformat()
        })
    
    except Exception as e:
        active_jobs[job_id].update({
            'status': 'failed',
            'error': str(e),
            'completed_at': datetime.now().isoformat()
        })
    
    # Move to history after a delay
    def move_to_history():
        time.sleep(60)  # Keep in active for 1 minute
        if job_id in active_jobs:
            job_history.append(active_jobs.pop(job_id))
            # Keep only last 100 in history
            while len(job_history) > 100:
                job_history.pop(0)
    
    history_thread = threading.Thread(target=move_to_history)
    history_thread.daemon = True
    history_thread.start()


@bp.route('/system/status')
def system_status():
    """Get system status information"""
    output_dir = current_app.config['OUTPUT_BASE_DIR']
    
    # Count total reports
    total_reports = 0
    if output_dir.exists():
        for category_dir in output_dir.iterdir():
            if category_dir.is_dir():
                total_reports += len(list(category_dir.glob("*.xlsx")))
    
    return jsonify({
        'status': 'operational',
        'active_jobs': len(active_jobs),
        'total_reports': total_reports,
        'timestamp': datetime.now().isoformat()
    })
